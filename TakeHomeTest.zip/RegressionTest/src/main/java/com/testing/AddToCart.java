package com.testing;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;

import static org.testng.Assert.assertNotNull;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chromium.ChromiumDriver;
import org.testng.annotations.AfterClass;

public class AddToCart {
	
	ChromeDriver driver = null;


	@BeforeClass
	public void beforeClass(){

	System.setProperty("webdriver.chrom.driver","C:\\Users\\bharathy\\Downloads\\chromedriver_win32\\chromdriver.exe");

	driver= new ChromeDriver();
	driver.get("http://amazon.in");
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	driver.manage().deleteAllCookies();

	}

	@Test
    public void testAddToCart(){
 	WebElement searchElement = driver.findElement(By.id("twotabsearchtextbox")); 
	searchElement.sendKeys("alexa echo dot"); 
	driver.findElement(By.id("nav-search-submit-button")).click(); 
	driver.get("https://www.amazon.in/All-new-Echo-Dot/dp/B084DWH53T/ref=sr_1_2?keywords=alexa+echo+dot&qid=1676911896&sr=8-2");
	
	WebElement AddToCart = driver.findElement(By.xpath("//*[@id=\"add-to-cart-button\"]"));
	AddToCart.click(); 
	
	 }

	@AfterClass
	public void afterClass(){
		WebElement GoToCart = driver.findElement(By.xpath("//*[@id=\"sw-gtc\"]/span/a"));
		GoToCart.click(); 
	driver.quit();
	}

}